/* Includes **************************************************************** */
#include "sensor.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
OWI owi1(PC3,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
OWI owi2(PC2,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
Sensor sensors[NUM_OF_SENSORS] = {Sensor(SENSOR_A_PIN, &owi1), Sensor(SENSOR_B_PIN, &owi2)};

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
Sensor::Sensor(byte pin, OWI *owi) {
    this->pin = pin;
    this->owi = owi;
    pinMode(pin, INPUT);
}


byte Sensor::getValue(uint8_t *sensor_type) {
    float dutyCycle = 0;
    uint8_t value = 0;
    *sensor_type = this->type;
    if(this->type == ALGOSENSOR_TYPE_1WIRE)
    {
        if(digitalRead(pin) == 0) 
        {
            this->type = ALGOSENSOR_TYPE_PWM;
            *sensor_type = ALGOSENSOR_TYPE_PWM;
            debugSENSOR(F("PWM device detected\r\n"));
            delay(1000);
            return 0;
        }
        delay(20);
        this->owi->readValue(0xbe, &value);
    }
    else
    {
        unsigned long pwmHighValue = pulseIn(pin, HIGH, PULSE_TIMEOUT);
        if(pwmHighValue != 0)
        {
            dutyCycle = (float(pwmHighValue) / CYCLE_TIME) * 100.0f;
        }
        else if (digitalRead(pin))
        {
            /* dutyCycle = 100; */
            this->type = ALGOSENSOR_TYPE_1WIRE;
            *sensor_type = ALGOSENSOR_TYPE_1WIRE;
            dutyCycle = 0;
            debugSENSOR(F("1Wire device detected\r\n"));;
            delay(1000);
        } else
        {
            dutyCycle = 0;
        }
        value = uint8_t(round(dutyCycle / 10));
    }
    debugSENSOR(F("Sensor value:  "));
    debugSENSOR(value);
    debugSENSOR(F("\r\n"));
    return value;
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
