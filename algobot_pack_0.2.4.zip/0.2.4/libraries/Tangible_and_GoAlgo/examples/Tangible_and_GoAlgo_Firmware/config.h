/**
 * @file        config.h
 * @author      semir-t
 * @date        December 2024
 * @version     1.0.0
 */

/* Define to prevent recursive inclusion *********************************** */
#ifndef __CONFIG_H
#define __CONFIG_H
/* Includes **************************************************************** */

/* Module configuration **************************************************** */

/* Exported constants ****************************************************** */
#define USE_CUSTOM_LEVEL_LIMITS             0
#define CUSTOM_LEVEL1_LIMIT                 20   
#define CUSTOM_LEVEL2_LIMIT                 50   
#define CUSTOM_LEVEL3_LIMIT                 90   

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */

#endif 
