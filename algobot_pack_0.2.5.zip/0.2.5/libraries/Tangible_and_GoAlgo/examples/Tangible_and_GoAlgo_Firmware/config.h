/**
 * @file        config.h
 * @author      semir-t
 * @date        December 2024
 * @version     1.0.0
 */

/* Define to prevent recursive inclusion *********************************** */
#ifndef __CONFIG_H
#define __CONFIG_H
/* Includes **************************************************************** */

/* Module configuration **************************************************** */

/* Exported constants ****************************************************** */
#define USE_CUSTOM_LEVEL_LIMITS             1
#define CUSTOM_LEVEL1_MIN                   2   
#define CUSTOM_LEVEL1_MAX                   5   
#define CUSTOM_LEVEL2_MIN                   5   
#define CUSTOM_LEVEL2_MAX                   20   
#define CUSTOM_LEVEL3_MIN                   20   
#define CUSTOM_LEVEL3_MAX                   50   
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */

#endif 
